# HDR Studio

HDR Studio is a native Windows GUI tool for packing and unpacking matching `.hdr` + `.src` archives.

## Highlights

- Pack folders into `.hdr` + `.src`
- Unpack matching archive pairs
- Turkish / English interface
- Native Windows GUI with no console window
- Drag & drop support
- Responsive background worker for long operations
- Archive bounds and path traversal checks
- Optional backup and overwrite behavior
- Custom dark controls, icon and progress rendering
- Double-buffered progress bar with bold percentage text
- x64 and x86 builds

## Repository layout

```text
.github/workflows/build.yml     GitHub build/release workflow
assets/                          Application artwork
source/main.go                   Complete application source
source/hdrstudio.ico             Multi-size application icon
tools/embed_pe_resources.py      PE icon/version/manifest resource builder
tools/generate_icon.py            Original application icon generator
build.ps1                        Local PowerShell build
sign_release.ps1                 Local Authenticode signing helper
build.sh                         Linux/WSL build
go.mod                           Go module definition
CODE_SIGNING.md                  Production signing setup
```

## Build

### GitHub Actions

Push the repository to GitHub. The workflow builds x64 and x86 automatically. Tagging a release such as `v1.0.3` also prepares release artifacts.

If production signing credentials are configured, the workflow signs both executables as the final binary step and verifies the signatures before publishing them.

### Windows PowerShell

Requirements:

- Go 1.23+
- Python 3
- `objcopy` or `llvm-objcopy`

```powershell
./build.ps1
```

### Linux / WSL

```bash
./build.sh
```

Generated files are written to `dist/`.

## Windows reputation warning

The repository can build unsigned binaries without any private signing material. Public downloads should be code-signed using the production workflow described in `CODE_SIGNING.md`.
